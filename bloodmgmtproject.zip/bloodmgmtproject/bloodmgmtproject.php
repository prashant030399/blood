
<!DOCTYPE html>
<html lang="en">
        <head>
                <meta charset="UTF_8">
                <meta name="viewport" content="width-device-width, initial-scale=1.0">
                <title>Document</title>
    <style>
        *
        {
        margin:0px;
        padding:0px;
        }
        .header1
        {
width:67.9%;
height:25px;
background-color:red;
color:white;
padding:15px 10px;
float:left;

        }
        .header2
        {
width:30%;
height:55px;
background-color:red;
color:white;
float:left;



        }

        .x li
        {
                display:inline-block;
                padding:15px 10px;
}

.x li:hover
{
        text-decoration:underline;
}


           .x a
   {
color:white;
text-decoration:none;
}




.side
{
        width:7%;
height:320px;
background-color:white;
float:left;
}
.side1
{
        width:60%;
height:320px;
background-color:white;
color:white;
float:left;

}
.side2
{
        width:33%;
height:320px;
background-color:white;
color:white;

float:left;

}
.box
{
        width:100%;
        margin-top:35px;
height:250px;
background-color:red;
color:white;
float:left;
border-radius:10px;

}
.button
{
        width:80px;
        height:30px;
        border-radius:10px;
        background-color:orange;
        color:white;
        margin-left:10px;
        border-color:white;

}
.image
{
width:40%;
height:250px;
margin-left:15%;
margin-top:35px;




}

.what
{

        width:100%;
        height:800px;
        background-color:white;
        color:black;


}
.city
{
        width:20%;
        height:auto;
        background-color:red;
        color:white;
        border-radius:5px;
        float:left;

}        
.footer
{
        width:100%;
        height:40px;
        background-color:red;
        color:white;

}
</style>

        </head>
   
 
<body>

        <form>
    <div class='header1'>  <h3> Blood Bank Management System</h3></div>
        <div class= 'header2'>
    <ul class='x'> 
    <li><a href="bloodmgmtproject.php">Home</a></li>
                <li><a href="adminloginpage.php">Admin</a></li>
                <li><a href="donorloginpage.php">Donor</a></li>
                <li><a href="patientloginpage.php">Patient</a></li>
                </ul>
</div>
<div class='side'></div>
<div class='side1'>
<div class='box'>

<h2 style="margin-left:10px;">What is Blood Bank Management System?</h2> <br>
        
<p style="margin-left:10px;  margin-right:10px;">




             Blood Bank Management System is a web-based system intends to 
    simplify and automate the process of searching for blood in case of emergency 
    and maintain the records of blood donors, recipients, blood donation programs and 
    blood stocks in the bank. Through the manual system of keeping theblood donation
     records, it is quite  difficult tomaintain the details of the donors and their 
     donations as reference because the data can be lost or redundant. In case of critical
      blood demand in one time,broadcasting the message should be done to all 
      donors with the respected blood group.







             <p>
           <br>
             <input type='button' value="Read more" class='button'>


              
                

                </div>
</div>

<div class='side2'>
<img src="blood.jpg"  class='image'>

</div>

<div class='what'>
        <h3 style="margin-left:7%;"> What is Blood Bank Management System?</h3>
        
        <p style="margin-left:7%;  margin-right:7%;  margin-top:5px" >


    Blood Bank Management System is a web-based system intends to 
    simplify and automate the process of searching for blood in case of emergency 
    and maintain the records of blood donors, recipients, blood donation programs and 
    blood stocks in the bank. Through the manual system of keeping theblood donation
     records, it is quite  difficult tomaintain the details of the donors and their 
     donations as reference because the data can be lost or redundant. In case of critical
      blood demand in one time,broadcasting the message should be done to all 
      donors with the respected blood group.












</p>
<br>

<p style="margin-left:7%;  margin-right:7%;" >


   The Purpose of this study is to develop a Blood Bank Management System to assist in the management
of blood donor records and ease/or control the distribution of blood in various parts of the country basing on
the hospital demands. Without quick and timely access to donor records creating market strategies for blood
donation, lobbying and sensitization of blood donors becomes very difficult.





</p>
<br>
<h4 style="margin-left:7%;"> Our Centers?  </h4>
<br>

<div class='city' style="margin-left:7%; ">
<p style="padding-left:5px">Jaipur</p>
<hr></p>

<p style="text-align:center;" >Jaipur became known as “The Pink City” when, in 1876, Maharaja Ram Singh had most of the buildings —the color of hospitality—in preparation.</p>

</div>
<div class='city' style="margin-left:2%; ">
<p style="padding-left:5px">Delhi</p>
<hr>
<p style="text-align:center;" >Delhi, city and national capital, and union territory, north-central India. The city of Delhi actually consists of two components: Old Delhi.</p>


</div>
<div class='city'style="margin-left:2%; ">
<p style="padding-left:5px">Patna</p>
<hr>
<p style="text-align:center;" >Patna is a riverside city that extends along the south bank of the Ganges (Ganga) River for about 12 miles (19 km). West of the old city lies.</p>


</div>
<div class='city' style="margin-left:2%; ">
<p style="padding-left:5px">Mumbai</p>
<hr>
<p style="text-align:center;" >Mumbai (also known as Bombay, the official name until 1995) is the capital city of the Indian state of Maharashtra. Mumbai lies on the konkan</p>


</div>

</div>

<div class='footer'>
<p style="text-align:center;  font-size:15px;  padding-top:10px">Project by Prashant</p>
</div>












</form>

</body>

</html>



